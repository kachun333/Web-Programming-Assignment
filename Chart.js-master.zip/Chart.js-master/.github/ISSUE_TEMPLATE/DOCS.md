---
name: Documentation
about: Are the docs lacking or missing something?
labels: 'type: documentation'
---

Documentation Is:

<!-- Please place an x (no spaces!) in all [ ] that apply -->

- [ ] Missing or needed
- [ ] Confusing
- [ ] Not Sure?

### Please Explain in Detail...


### Your Proposal for Changes


### Example
<!--
  Provide a link to a live example demonstrating the issue or feature to be documented:
  https://codepen.io/pen?template=JXVYzq
-->
